package pe.edu.upc.eppenapc05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpPenaPC05ApplicationTests {

    @Test
    void contextLoads() {
    }
}
