package pe.edu.upc.eppenapc05.phrjdtos;

import java.io.Serializable;

public class JwtRequestDTO implements Serializable {

    private String rjphUsername;
    private String rjphPassword;

    public JwtRequestDTO() {
        super();
    }

    public JwtRequestDTO(String rjphUsername, String rjphPassword) {
        super();
        this.rjphUsername = rjphUsername;
        this.rjphPassword = rjphPassword;
    }

    public String getRjphUsername() {
        return rjphUsername;
    }

    public void setRjphUsername(String rjphUsername) {
        this.rjphUsername = rjphUsername;
    }

    public String getRjphPassword() {
        return rjphPassword;
    }

    public void setRjphPassword(String rjphPassword) {
        this.rjphPassword = rjphPassword;
    }
}
