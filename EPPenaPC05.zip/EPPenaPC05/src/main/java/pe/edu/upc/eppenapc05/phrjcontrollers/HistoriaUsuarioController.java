package pe.edu.upc.eppenapc05.phrjcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.eppenapc05.phrjdtos.CantidadHUPorResponsableDTO;
import pe.edu.upc.eppenapc05.phrjdtos.HistoriaUsuarioDTO;
import pe.edu.upc.eppenapc05.phrjentities.HistoriaUsuario;
import pe.edu.upc.eppenapc05.phrjentities.ProductBacklog;
import pe.edu.upc.eppenapc05.phrjrepositories.IProductBacklogRepository;
import pe.edu.upc.eppenapc05.phrjservicesinterfaces.IHistoriaUsuarioService;

import java.util.Optional;

@RestController
public class HistoriaUsuarioController {

    @Autowired
    private IHistoriaUsuarioService rjphHuS;

    @Autowired
    private IProductBacklogRepository rjphPbR;

    @PreAuthorize("hasAuthority('DEVELOPER')")
    @PostMapping("/stories-hernandez")
    public ResponseEntity<String> registrar(@RequestBody HistoriaUsuarioDTO dto) {
        Optional<ProductBacklog> pb = rjphPbR.findById(dto.getRjphIdBacklog());
        if (pb.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ProductBacklog no encontrado");
        }
        HistoriaUsuario hu = new HistoriaUsuario();
        hu.setRjphTitulo(dto.getRjphTitulo());
        hu.setRjphDescripcion(dto.getRjphDescripcion());
        hu.setRjphCantidadCriteriosAceptacion(dto.getRjphCantidadCriteriosAceptacion());
        hu.setRjphResponsable(dto.getRjphResponsable());
        hu.setRjphProductBacklog(pb.get());
        HistoriaUsuario rjphSaved = rjphHuS.insertar(hu);
        return ResponseEntity.status(HttpStatus.CREATED).body("Se registró correctamente el ID: " + rjphSaved.getRjphIdHU());
    }

    @PreAuthorize("hasAuthority('MANAGEMENT')")
    @GetMapping("/05/hernandez-HU03")
    public ResponseEntity<?> cantidadPorResponsable(@RequestParam("responsable") String responsable) {
        Long rjphCantidad = rjphHuS.contarPorResponsable(responsable);
        if (rjphCantidad == 0) {
            return ResponseEntity.ok("No existe HU para este colaborador");
        }
        CantidadHUPorResponsableDTO rjphDto = new CantidadHUPorResponsableDTO(responsable, rjphCantidad);
        return ResponseEntity.ok(rjphDto);
    }
}
