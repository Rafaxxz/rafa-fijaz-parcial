package pe.edu.upc.eppenapc05.phrjservicesinterfaces;

import pe.edu.upc.eppenapc05.phrjentities.HistoriaUsuario;

import java.util.List;

public interface IHistoriaUsuarioService {
    HistoriaUsuario insertar(HistoriaUsuario hu);
    Long contarPorResponsable(String responsable);
    List<Object[]> contarPorBacklog();
}
