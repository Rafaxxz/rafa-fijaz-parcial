package pe.edu.upc.eppenapc05.phrjrepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.eppenapc05.phrjentities.ProductBacklog;

@Repository
public interface IProductBacklogRepository extends JpaRepository<ProductBacklog, Long> {
}
