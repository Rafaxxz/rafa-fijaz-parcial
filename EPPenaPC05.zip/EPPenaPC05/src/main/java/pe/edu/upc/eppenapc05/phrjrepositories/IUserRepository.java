package pe.edu.upc.eppenapc05.phrjrepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.eppenapc05.phrjentities.Users;

@Repository
public interface IUserRepository extends JpaRepository<Users, Long> {
    Users findOneByRjphUsername(String rjphUsername);
}
