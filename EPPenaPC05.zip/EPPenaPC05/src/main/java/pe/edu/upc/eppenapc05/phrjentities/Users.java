package pe.edu.upc.eppenapc05.phrjentities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "users")
public class Users implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rjphId;

    @Column(length = 30, unique = true)
    private String rjphUsername;

    @Column(length = 200)
    private String rjphPassword;

    private Boolean rjphEnabled;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private List<Role> rjphRoles;

    public Long getRjphId() {
        return rjphId;
    }

    public void setRjphId(Long rjphId) {
        this.rjphId = rjphId;
    }

    public String getRjphUsername() {
        return rjphUsername;
    }

    public void setRjphUsername(String rjphUsername) {
        this.rjphUsername = rjphUsername;
    }

    public String getRjphPassword() {
        return rjphPassword;
    }

    public void setRjphPassword(String rjphPassword) {
        this.rjphPassword = rjphPassword;
    }

    public Boolean getRjphEnabled() {
        return rjphEnabled;
    }

    public void setRjphEnabled(Boolean rjphEnabled) {
        this.rjphEnabled = rjphEnabled;
    }

    public List<Role> getRjphRoles() {
        return rjphRoles;
    }

    public void setRjphRoles(List<Role> rjphRoles) {
        this.rjphRoles = rjphRoles;
    }
}
