package pe.edu.upc.eppenapc05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpPenaPC05Application {
    public static void main(String[] args) {
        SpringApplication.run(EpPenaPC05Application.class, args);
    }
}
