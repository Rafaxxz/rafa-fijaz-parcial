package pe.edu.upc.eppenapc05.phrjdtos;

public class CantidadHUPorResponsableDTO {

    private String rjphResponsable;
    private Long rjphCantidad;

    public CantidadHUPorResponsableDTO() {
    }

    public CantidadHUPorResponsableDTO(String rjphResponsable, Long rjphCantidad) {
        this.rjphResponsable = rjphResponsable;
        this.rjphCantidad = rjphCantidad;
    }

    public String getRjphResponsable() {
        return rjphResponsable;
    }

    public void setRjphResponsable(String rjphResponsable) {
        this.rjphResponsable = rjphResponsable;
    }

    public Long getRjphCantidad() {
        return rjphCantidad;
    }

    public void setRjphCantidad(Long rjphCantidad) {
        this.rjphCantidad = rjphCantidad;
    }
}
