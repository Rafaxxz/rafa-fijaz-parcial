package pe.edu.upc.eppenapc05.phrjservicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import pe.edu.upc.eppenapc05.phrjentities.Users;
import pe.edu.upc.eppenapc05.phrjrepositories.IUserRepository;

import java.util.ArrayList;
import java.util.List;

//Clase 2
@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private IUserRepository rjphRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user = rjphRepo.findOneByRjphUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException(String.format("User not exists", username));
        }

        List<GrantedAuthority> roles = new ArrayList<>();

        user.getRjphRoles().forEach(rol -> {
            roles.add(new SimpleGrantedAuthority(rol.getRjphRol()));
        });

        UserDetails ud = new org.springframework.security.core.userdetails.User(
                user.getRjphUsername(), user.getRjphPassword(),
                user.getRjphEnabled(), true, true, true, roles);

        return ud;
    }
}
