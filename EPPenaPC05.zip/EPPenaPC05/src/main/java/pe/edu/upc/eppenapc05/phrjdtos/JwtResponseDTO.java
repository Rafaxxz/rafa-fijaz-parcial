package pe.edu.upc.eppenapc05.phrjdtos;

import java.io.Serializable;

public class JwtResponseDTO implements Serializable {

    private final String rjphJwttoken;

    public JwtResponseDTO(String rjphJwttoken) {
        super();
        this.rjphJwttoken = rjphJwttoken;
    }

    public String getRjphJwttoken() {
        return rjphJwttoken;
    }
}
