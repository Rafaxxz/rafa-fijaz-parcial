package pe.edu.upc.eppenapc05.phrjcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.eppenapc05.phrjdtos.JwtRequestDTO;
import pe.edu.upc.eppenapc05.phrjdtos.JwtResponseDTO;
import pe.edu.upc.eppenapc05.phrjsecurities.JwtTokenUtil;
import pe.edu.upc.eppenapc05.phrjservicesimplements.JwtUserDetailsService;

//Clase 3
@RestController
@CrossOrigin
public class JwtAuthenticationController {

    @Autowired
    private AuthenticationManager rjphAuthenticationManager;

    @Autowired
    private JwtTokenUtil rjphJwtTokenUtil;

    @Autowired
    private JwtUserDetailsService rjphUserDetailsService;

    @PostMapping("/examenep-17731/scrum")
    public ResponseEntity<JwtResponseDTO> login(@RequestBody JwtRequestDTO req) throws Exception {
        authenticate(req.getRjphUsername(), req.getRjphPassword());
        final UserDetails userDetails = rjphUserDetailsService.loadUserByUsername(req.getRjphUsername());
        final String token = rjphJwtTokenUtil.generateToken(userDetails);
        return ResponseEntity.ok(new JwtResponseDTO(token));
    }

    private void authenticate(String username, String password) throws Exception {
        try {
            rjphAuthenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }
}
