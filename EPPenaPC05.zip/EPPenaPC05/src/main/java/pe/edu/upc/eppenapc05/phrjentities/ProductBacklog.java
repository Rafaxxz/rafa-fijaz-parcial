package pe.edu.upc.eppenapc05.phrjentities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "product_backlog")
public class ProductBacklog implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rjphCodigo;

    private String rjphNombre;
    private String rjphObjetivo;
    private LocalDate rjphFechaCreacion;
    private String rjphVersion;
    private Integer rjphCantidadHistorias;
    private Integer rjphPrioridadGlobal;

    @PrePersist
    protected void onCreate() {
        rjphFechaCreacion = LocalDate.now();
    }

    public Long getRjphCodigo() {
        return rjphCodigo;
    }

    public void setRjphCodigo(Long rjphCodigo) {
        this.rjphCodigo = rjphCodigo;
    }

    public String getRjphNombre() {
        return rjphNombre;
    }

    public void setRjphNombre(String rjphNombre) {
        this.rjphNombre = rjphNombre;
    }

    public String getRjphObjetivo() {
        return rjphObjetivo;
    }

    public void setRjphObjetivo(String rjphObjetivo) {
        this.rjphObjetivo = rjphObjetivo;
    }

    public LocalDate getRjphFechaCreacion() {
        return rjphFechaCreacion;
    }

    public void setRjphFechaCreacion(LocalDate rjphFechaCreacion) {
        this.rjphFechaCreacion = rjphFechaCreacion;
    }

    public String getRjphVersion() {
        return rjphVersion;
    }

    public void setRjphVersion(String rjphVersion) {
        this.rjphVersion = rjphVersion;
    }

    public Integer getRjphCantidadHistorias() {
        return rjphCantidadHistorias;
    }

    public void setRjphCantidadHistorias(Integer rjphCantidadHistorias) {
        this.rjphCantidadHistorias = rjphCantidadHistorias;
    }

    public Integer getRjphPrioridadGlobal() {
        return rjphPrioridadGlobal;
    }

    public void setRjphPrioridadGlobal(Integer rjphPrioridadGlobal) {
        this.rjphPrioridadGlobal = rjphPrioridadGlobal;
    }
}
