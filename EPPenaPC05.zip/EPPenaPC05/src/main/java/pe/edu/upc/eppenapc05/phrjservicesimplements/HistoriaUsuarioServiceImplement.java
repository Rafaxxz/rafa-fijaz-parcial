package pe.edu.upc.eppenapc05.phrjservicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.eppenapc05.phrjentities.HistoriaUsuario;
import pe.edu.upc.eppenapc05.phrjrepositories.IHistoriaUsuarioRepository;
import pe.edu.upc.eppenapc05.phrjservicesinterfaces.IHistoriaUsuarioService;

import java.util.List;

@Service
public class HistoriaUsuarioServiceImplement implements IHistoriaUsuarioService {

    @Autowired
    private IHistoriaUsuarioRepository rjphRepo;

    @Override
    public HistoriaUsuario insertar(HistoriaUsuario hu) {
        return rjphRepo.save(hu);
    }

    @Override
    public Long contarPorResponsable(String responsable) {
        return rjphRepo.contarPorResponsable(responsable);
    }

    @Override
    public List<Object[]> contarPorBacklog() {
        return rjphRepo.contarPorBacklog();
    }
}
