package pe.edu.upc.eppenapc05.phrjdtos;

public class HistoriaUsuarioDTO {

    private String rjphTitulo;
    private String rjphDescripcion;
    private Integer rjphCantidadCriteriosAceptacion;
    private String rjphResponsable;
    private Long rjphIdBacklog;

    public String getRjphTitulo() {
        return rjphTitulo;
    }

    public void setRjphTitulo(String rjphTitulo) {
        this.rjphTitulo = rjphTitulo;
    }

    public String getRjphDescripcion() {
        return rjphDescripcion;
    }

    public void setRjphDescripcion(String rjphDescripcion) {
        this.rjphDescripcion = rjphDescripcion;
    }

    public Integer getRjphCantidadCriteriosAceptacion() {
        return rjphCantidadCriteriosAceptacion;
    }

    public void setRjphCantidadCriteriosAceptacion(Integer rjphCantidadCriteriosAceptacion) {
        this.rjphCantidadCriteriosAceptacion = rjphCantidadCriteriosAceptacion;
    }

    public String getRjphResponsable() {
        return rjphResponsable;
    }

    public void setRjphResponsable(String rjphResponsable) {
        this.rjphResponsable = rjphResponsable;
    }

    public Long getRjphIdBacklog() {
        return rjphIdBacklog;
    }

    public void setRjphIdBacklog(Long rjphIdBacklog) {
        this.rjphIdBacklog = rjphIdBacklog;
    }
}
