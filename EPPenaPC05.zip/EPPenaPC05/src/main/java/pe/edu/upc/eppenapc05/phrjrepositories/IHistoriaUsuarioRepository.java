package pe.edu.upc.eppenapc05.phrjrepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.eppenapc05.phrjentities.HistoriaUsuario;

import java.util.List;

@Repository
public interface IHistoriaUsuarioRepository extends JpaRepository<HistoriaUsuario, Long> {

    @Query("SELECT COUNT(h) FROM HistoriaUsuario h WHERE h.rjphResponsable = :responsable")
    Long contarPorResponsable(@Param("responsable") String responsable);

    @Query(value = "SELECT id_backlog, COUNT(*) FROM historia_usuario GROUP BY id_backlog", nativeQuery = true)
    List<Object[]> contarPorBacklog();
}
