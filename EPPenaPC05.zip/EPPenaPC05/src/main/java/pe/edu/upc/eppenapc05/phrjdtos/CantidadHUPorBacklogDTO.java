package pe.edu.upc.eppenapc05.phrjdtos;

public class CantidadHUPorBacklogDTO {

    private Long rjphIdBacklog;
    private Long rjphCantidad;

    public CantidadHUPorBacklogDTO() {
    }

    public CantidadHUPorBacklogDTO(Long rjphIdBacklog, Long rjphCantidad) {
        this.rjphIdBacklog = rjphIdBacklog;
        this.rjphCantidad = rjphCantidad;
    }

    public Long getRjphIdBacklog() {
        return rjphIdBacklog;
    }

    public void setRjphIdBacklog(Long rjphIdBacklog) {
        this.rjphIdBacklog = rjphIdBacklog;
    }

    public Long getRjphCantidad() {
        return rjphCantidad;
    }

    public void setRjphCantidad(Long rjphCantidad) {
        this.rjphCantidad = rjphCantidad;
    }
}
