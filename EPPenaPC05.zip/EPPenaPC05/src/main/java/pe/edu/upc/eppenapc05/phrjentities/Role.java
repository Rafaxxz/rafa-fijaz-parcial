package pe.edu.upc.eppenapc05.phrjentities;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "roles", uniqueConstraints = {@UniqueConstraint(columnNames = {"user_id", "rjph_rol"})})
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rjphId;

    private String rjphRol;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users rjphUser;

    public Long getRjphId() {
        return rjphId;
    }

    public void setRjphId(Long rjphId) {
        this.rjphId = rjphId;
    }

    public String getRjphRol() {
        return rjphRol;
    }

    public void setRjphRol(String rjphRol) {
        this.rjphRol = rjphRol;
    }

    public Users getRjphUser() {
        return rjphUser;
    }

    public void setRjphUser(Users rjphUser) {
        this.rjphUser = rjphUser;
    }
}
