package pe.edu.upc.eppenapc05.phrjentities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "historia_usuario")
public class HistoriaUsuario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rjphIdHU;

    @Column(nullable = false)
    private String rjphTitulo;

    private String rjphDescripcion;

    @Column(nullable = false)
    private Integer rjphCantidadCriteriosAceptacion;

    @Column(nullable = false)
    private String rjphResponsable;

    private LocalDate rjphFechaCreacion;

    @ManyToOne
    @JoinColumn(name = "id_backlog", nullable = false)
    private ProductBacklog rjphProductBacklog;

    @PrePersist
    protected void onCreate() {
        rjphFechaCreacion = LocalDate.now();
    }

    public Long getRjphIdHU() {
        return rjphIdHU;
    }

    public void setRjphIdHU(Long rjphIdHU) {
        this.rjphIdHU = rjphIdHU;
    }

    public String getRjphTitulo() {
        return rjphTitulo;
    }

    public void setRjphTitulo(String rjphTitulo) {
        this.rjphTitulo = rjphTitulo;
    }

    public String getRjphDescripcion() {
        return rjphDescripcion;
    }

    public void setRjphDescripcion(String rjphDescripcion) {
        this.rjphDescripcion = rjphDescripcion;
    }

    public Integer getRjphCantidadCriteriosAceptacion() {
        return rjphCantidadCriteriosAceptacion;
    }

    public void setRjphCantidadCriteriosAceptacion(Integer rjphCantidadCriteriosAceptacion) {
        this.rjphCantidadCriteriosAceptacion = rjphCantidadCriteriosAceptacion;
    }

    public String getRjphResponsable() {
        return rjphResponsable;
    }

    public void setRjphResponsable(String rjphResponsable) {
        this.rjphResponsable = rjphResponsable;
    }

    public LocalDate getRjphFechaCreacion() {
        return rjphFechaCreacion;
    }

    public void setRjphFechaCreacion(LocalDate rjphFechaCreacion) {
        this.rjphFechaCreacion = rjphFechaCreacion;
    }

    public ProductBacklog getRjphProductBacklog() {
        return rjphProductBacklog;
    }

    public void setRjphProductBacklog(ProductBacklog rjphProductBacklog) {
        this.rjphProductBacklog = rjphProductBacklog;
    }
}
