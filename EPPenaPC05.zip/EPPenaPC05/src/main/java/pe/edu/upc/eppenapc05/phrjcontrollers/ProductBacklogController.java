package pe.edu.upc.eppenapc05.phrjcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.eppenapc05.phrjdtos.CantidadHUPorBacklogDTO;
import pe.edu.upc.eppenapc05.phrjservicesinterfaces.IHistoriaUsuarioService;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductBacklogController {

    @Autowired
    private IHistoriaUsuarioService rjphHuS;

    @GetMapping("/ep-free")
    public ResponseEntity<?> cantidadPorBacklog() {
        List<Object[]> rjphLista = rjphHuS.contarPorBacklog();
        if (rjphLista.isEmpty()) {
            return ResponseEntity.ok("No hay datos");
        }
        List<CantidadHUPorBacklogDTO> rjphRespuesta = new ArrayList<>();
        for (Object[] fila : rjphLista) {
            CantidadHUPorBacklogDTO rjphDto = new CantidadHUPorBacklogDTO();
            rjphDto.setRjphIdBacklog(((Number) fila[0]).longValue());
            rjphDto.setRjphCantidad(((Number) fila[1]).longValue());
            rjphRespuesta.add(rjphDto);
        }
        return ResponseEntity.ok(rjphRespuesta);
    }
}
